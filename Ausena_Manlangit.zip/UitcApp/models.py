from django.db import models
from django.contrib.auth.models import AbstractUser 




# Create your models here.

class Registration(AbstractUser):
        
    idnumber = models.CharField(max_length=30, verbose_name='ID Number', unique=True)


class Dashboard(models.Model):
    STATUS = (
            ('Approved', 'Approved' ),
            ('Pending', 'Pending'),
            )
    date_borrow = models.DateTimeField(null = True)
    date_return = models.DateTimeField(null = True)
    studid = models.CharField(max_length=12, null=True)
    equipid = models.CharField(max_length=12, null=True)
    inventory = models.CharField(max_length=100, null=True)
    status = models.CharField(max_length=30, null=True, choices=STATUS)
    
    def __str__(self):
        return self.inventory

class Inventory(models.Model):
    STATUS = (
            ('Available', 'Available' ),
            ('Not Available', 'Not Available'),
            )
    Itemname = models.CharField(max_length=50, null=True)
    status = models.CharField(max_length=30, null=True, choices=STATUS)
    
    def __str__(self):
        return self.Itemname
class Summary(models.Model):
    STATUS = (
            ('Approved', 'Approved' ),
            ('Pending', 'Pending'),
            )
    date_borrow = models.DateTimeField(null = True)
    date_return = models.DateTimeField(null = True)
    studid = models.CharField(max_length=12, null=True)
    equipid = models.CharField(max_length=12, null=True)
    inventory = models.CharField(max_length=100, null=True)
    status = models.CharField(max_length=30, null=True, choices=STATUS)
    
    def __str__(self):
        return self.inventory

class Dashstud(models.Model):
    STATUS = (
            ('Available', 'Available' ),
            ('Not Available', 'Not Available'),
            )
    Itemname = models.CharField(max_length=50, null=True)
    status = models.CharField(max_length=30, null=True, choices=STATUS)
    
    def __str__(self):
        return self.Itemname

class Borrowing(models.Model):
    STATUS = (
            ('Available', 'Available' ),
            ('Not Available', 'Not Available'),
            )
    Itemname = models.CharField(max_length=50, null=True)
    status = models.CharField(max_length=30, null=True, choices=STATUS)
    
    def __str__(self):
        return self.Itemname

class Borrowingstatus(models.Model):
    STATUS = (
            ('Approved', 'Approved' ),
            ('Pending', 'Pending'),
            )
    date_borrow = models.DateTimeField(null = True)
    date_return = models.DateTimeField(null = True)
    studid = models.CharField(max_length=12, null=True)
    equipid = models.CharField(max_length=12, null=True)
    inventory = models.CharField(max_length=100, null=True)
    status = models.CharField(max_length=30, null=True, choices=STATUS)
    
    def __str__(self):
        return self.inventory

class Add(models.Model):
    STATUS = (
            ('Available', 'Available' ),
            ('Not Available', 'Not Available'),
            )
    name = models.CharField(verbose_name='Equipment Name', max_length=30, null=True)
    status = models.CharField(max_length=30, null=True, choices=STATUS)

    def __str__(self):
        return self.name

class Login(models.Model):
    username = models.CharField(max_length=30, null=True)
    password = models.CharField(max_length=30, null=True)

class Loginstaff(models.Model):
    staff = models.CharField(max_length=30, null=True)
    staffpass = models.CharField(max_length=30, null=True)
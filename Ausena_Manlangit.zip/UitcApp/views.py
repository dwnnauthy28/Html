from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpResponse
from matplotlib.style import context
from .forms import *
from .models import *
# Create your views here.


def registration(request):
    form = CreateUserForm()
    if request.method == "POST":
        form = CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('loginborrower')
    context = {'form':form}
    return render (request, 'html/registration.html', context)

    
def userpage(request):
    return render(request, 'html/userpage.html')


def loginborrower(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password =request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request,'Sign in')
            return redirect('dashstud')
        else:
            messages.info(request, 'Username OR password is incorrect')
    return render(request, 'html/loginborrower.html',)



def loginstaff(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password =request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.info(request, 'Username OR password is incorrect')
    return render(request, 'html/loginstaff.html',)

def dashboard(request):
    itemname = Dashboard.objects.all()
    return render(request, 'html/dashboard.html' , {'itemname':itemname})

def dashstud(request):
    itemname = Dashstud.objects.all()
    return render(request, 'html/dashboard-student.html',{'itemname':itemname})

def borrowing(request):
    itemname = Borrowing.objects.all()
    return render(request, 'html/borrowing.html',{'itemname':itemname})

def borrowstatus(request):
    borrowid = Borrowingstatus.objects.all()
    return render(request, 'html/Borrowstatus (1).html',{'borrowid':borrowid})

def inventory(request):
    itemname = Add.objects.all()
    return render(request, 'html/inventory.html' , {'itemname':itemname})

def inventoryadd(request):
    form = Addform
    if request.method == "POST":
        form = Addform(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inventory')
    context = {'form':form}
    return render(request, 'html/inventoryadd.html', context)

def summary(request):
    eborrowstatus = Summary.objects.all()
    return render(request, 'html/summary.html',{'eborrowstatus':eborrowstatus})



def dell(request):
    return render(request,'html/delete.html')

def updatepage(request):
    return render(request,'html/updatepage.html')


def update(request,pk):
    update = Add.objects.get(id=pk)
    form = Addform(instance=update)
    return render(request,'html/update.html')

def Adding(request):
    if request.method == 'POST':
        form = AddForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('Adding')
    form= AddForm
    return render(request, 'html/inventory.html', {'form':form})

def delete(request, pk):
	eq = Add.objects.get(id=pk)
	if request.method == "POST":
		eq.delete()
		return redirect('delete')

	context = {'name':eq}
	return render(request, 'html/delete.html', context)
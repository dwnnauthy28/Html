from django.db import models
from django.contrib.auth.models import AbstractUser 




# Create your models here.

class Registration(AbstractUser):
        
    idnumber = models.CharField(max_length=30, verbose_name='ID Number', unique=True)
    userType = models.CharField(max_length=10, blank=True)


class EquipmentBorrow(models.Model):
    date_borrow = models.DateTimeField(null = True)
    date_return = models.DateTimeField(null = True)
    studid = models.CharField(max_length=12, null=True)
    equipid = models.CharField(max_length=12, null=True)  
 

class Inventory(models.Model):   
    status = [
        ('AVAILABLE', 'AVAILABLE'),
        ('NOT AVAILABLE', 'NOT AVAILABLE'),
    ]
    itemName = models.CharField(max_length=30, null=True, verbose_name= 'itemName' )
    statusType = models.CharField(max_length=20, choices=status, verbose_name= 'status')
    date = models.DateTimeField(auto_now_add= True, verbose_name= 'dateTime')

class Summary(models.Model):
    BorrowerID = models.ForeignKey(Registration, on_delete=models.CASCADE)

class Dashstud(models.Model):
    STATUS = (
            ('Available', 'Available' ),
            ('Not Available', 'Not Available'),
            )
    Itemname = models.CharField(max_length=50, null=True)
    status = models.CharField(max_length=30, null=True, choices=STATUS)
    
class Borrowing(models.Model):
    borrowerID = models.ForeignKey(Registration, on_delete=models.CASCADE)
    Itemname = models.CharField(max_length=50, null=True)
    status = models.CharField(max_length=30, null=True, choices=STATUS)

class Borrowingstatus(models.Model):
    date_borrow = models.DateTimeField(null = True)
    date_return = models.DateTimeField(null = True)
    studid = models.CharField(max_length=12, null=True)
    equipid = models.CharField(max_length=12, null=True)
    inventory = models.CharField(max_length=100, null=True)
    status = models.CharField(max_length=30, null=True, choices=STATUS)

class Add(models.Model):
    STATUS = (
            ('Available', 'Available' ),
            ('Not Available', 'Not Available'),
            )
    name = models.CharField(verbose_name='Equipment Name', max_length=30, null=True)
    status = models.CharField(max_length=30, null=True, choices=STATUS)
 
class Login(models.Model):
    username = models.CharField(max_length=30, null=True)
    password = models.CharField(max_length=30, null=True)

class Loginstaff(models.Model):
    staff = models.CharField(max_length=30, null=True)
    staffpass = models.CharField(max_length=30, null=True)
from django.contrib import admin
from django.urls import path
from django.urls.conf import include


from . import views

urlpatterns = [
    path('', views.userpage, name="userpage"),
    path('updatepage/', views.updatepage, name= "updatepage"),
    path('loginborrower/', views.loginborrower, name= "loginborrower"),
    path('registration/', views.registration, name= "registration"),
    path('registrationstaff/', views.registrationstaff, name= "registrationstaff"),
    path('loginstaff/', views.loginstaff, name= "loginstaff"),
    path('dashboard/', views.dashboard, name= "dashboard"),
    path('dashstud/', views.dashstud, name= "dashstud"),
    path('inventory/', views.inventory, name= "inventory"),
    path('inventoryadd/', views.inventoryadd, name= "inventoryadd"),
    path('borrowing/', views.borrowing, name= "borrowing"),
    path('borrowstatus/', views.borrowstatus, name= "borrowstatus"),
    path('summary/', views.summary, name= "summary"),
    path('dell/', views.dell, name= "dell"),
    path('delete/str:pk/', views.delete, name = "delete" ),
    path('Adding/', views.Adding, name = "Adding" ),
    path('update/str:pk/', views.update, name = "update" ),
]
from cProfile import label
from turtle import update
from django import forms
from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from matplotlib import widgets

from .models import Add
from .models import Inventory
from .models import Dashboard
from .models import Dashstud
from .models import Borrowing
from .models import Borrowingstatus
from .models import Summary
from .models import Registration




class CreateUserForm(UserCreationForm):
	class Meta:
		fields = ['fname', 'sname', 'inum', 'email', 'ps1', 'ps2']

class Dashboardform(ModelForm):
    class Meta:
        model = Dashboard
        fields = '__all__'

class Registrationform(ModelForm):
    class Meta:
        model = Registration
        fields = '__all__'
        labels ={
            'fname':'',
            'sname':'',
            'inum':'',
            'email':'',
            'ps':'',
            'ps2':'',
        }
        widgets = {
            'fname':forms.TextInput(attrs={'class':'form-control rounded-pill form-control-lg', 'placeholder':'Firstname'}),
            'sname':forms.TextInput(attrs={'class':'form-control rounded-pill form-control-lg','placeholder':'Surname'}),
            'inum':forms.TextInput(attrs={'class':'form-control rounded-pill form-control-lg','placeholder':'ID Number'}),
            'email':forms.EmailInput(attrs={'class':'form-control rounded-pill form-control-lgl','placeholder':'Email'}),
            'ps':forms.PasswordInput(attrs={'class':'form-control rounded-pill form-control-lg','placeholder':'Password'}),
            'ps2':forms.PasswordInput(attrs={'class':'form-control rounded-pill form-control-lg','placeholder':'Confirm Password'}),
            }


class Inventoryform(ModelForm):
    class Meta:
        model = Inventory
        fields = '__all__'

class Summaryform(ModelForm):
    class Meta:
        model = Summary
        fields = '__all__'

class Dashstudform(ModelForm):
    class Meta:
        model = Dashstud
        fields = '__all__'

class Borrowingform(ModelForm):
    class Meta:
        model = Borrowing
        fields = '__all__'

class Borrowstatusform(ModelForm):
    class Meta:
        model = Borrowingstatus
        fields = '__all__'


class Updateform(ModelForm):
    class Meta:
        model = Add
        fields = '__all__'

class Addform(ModelForm):
	class Meta:
		model = Add
		fields = ['name','status']
from django.contrib import admin

from .models import Add, Dashboard, Inventory, Summary, Dashstud, Borrowing, Borrowingstatus


from .models  import Registration
# Register your models here.

admin.site.register(Registration)
admin.site.register(Add)
admin.site.register(Dashboard)
admin.site.register(Inventory)
admin.site.register(Summary)
admin.site.register(Dashstud)
admin.site.register(Borrowing)
admin.site.register(Borrowingstatus)



